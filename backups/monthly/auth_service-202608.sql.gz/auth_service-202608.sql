--
-- PostgreSQL database cluster dump
--

\restrict LKCP5irwXOfErN7QzbZUMa8C4g6blj5S2GuwvFsSmVYd3WTYaDJAPnweb2iD9rB

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:i6TylttXEtOGY0HwNAoUfw==$yR+5aSGRO4pozJ+VubT1uwP+DV0UdrdtkJMHpM5l1Cg=:fuOnHyA11LFBv2UMWKcHr6jH9zOlZi5PakOKVUymgLQ=';

--
-- User Configurations
--








\unrestrict LKCP5irwXOfErN7QzbZUMa8C4g6blj5S2GuwvFsSmVYd3WTYaDJAPnweb2iD9rB

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict NFRb79cNe15RpEUshVREyhaz9Aj2kDzOrIqRQ6dC9abxW2ydGhAKnhP9JCydygE

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict NFRb79cNe15RpEUshVREyhaz9Aj2kDzOrIqRQ6dC9abxW2ydGhAKnhP9JCydygE

--
-- Database "auth_service" dump
--

--
-- PostgreSQL database dump
--

\restrict Ktkv0ibbcHEWHcM6W4nWgArai4v82ubdsAv9LOC3F0AQW76XQeoovnCz0wIOG2Z

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth_service; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE auth_service WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE auth_service OWNER TO postgres;

\unrestrict Ktkv0ibbcHEWHcM6W4nWgArai4v82ubdsAv9LOC3F0AQW76XQeoovnCz0wIOG2Z
\connect auth_service
\restrict Ktkv0ibbcHEWHcM6W4nWgArai4v82ubdsAv9LOC3F0AQW76XQeoovnCz0wIOG2Z

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: public?schema=prisma_shadow; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "public?schema=prisma_shadow";


ALTER SCHEMA "public?schema=prisma_shadow" OWNER TO postgres;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Role" AS ENUM (
    'USER',
    'STREAMER',
    'ADMIN'
);


ALTER TYPE public."Role" OWNER TO postgres;

--
-- Name: Role; Type: TYPE; Schema: public?schema=prisma_shadow; Owner: postgres
--

CREATE TYPE "public?schema=prisma_shadow"."Role" AS ENUM (
    'USER',
    'STREAMER',
    'ADMIN'
);


ALTER TYPE "public?schema=prisma_shadow"."Role" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    id text NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    role public."Role" DEFAULT 'USER'::public."Role" NOT NULL,
    password text NOT NULL,
    avatar text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id text NOT NULL,
    text text,
    "streamId" text NOT NULL,
    "accountId" text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "replyToId" text
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: streams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.streams (
    id text NOT NULL,
    title text NOT NULL,
    "accountId" text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.streams OWNER TO postgres;

--
-- Name: accounts; Type: TABLE; Schema: public?schema=prisma_shadow; Owner: postgres
--

CREATE TABLE "public?schema=prisma_shadow".accounts (
    id text NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    role "public?schema=prisma_shadow"."Role" DEFAULT 'USER'::"public?schema=prisma_shadow"."Role" NOT NULL,
    password text NOT NULL,
    avatar text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public?schema=prisma_shadow".accounts OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: public?schema=prisma_shadow; Owner: postgres
--

CREATE TABLE "public?schema=prisma_shadow".messages (
    id text NOT NULL,
    text text,
    "streamId" text NOT NULL,
    "accountId" text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public?schema=prisma_shadow".messages OWNER TO postgres;

--
-- Name: streams; Type: TABLE; Schema: public?schema=prisma_shadow; Owner: postgres
--

CREATE TABLE "public?schema=prisma_shadow".streams (
    id text NOT NULL,
    title text NOT NULL,
    "accountId" text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public?schema=prisma_shadow".streams OWNER TO postgres;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
b010303f-0201-4977-bb39-8093fc29cadf	bd67384cb72fb175c9b2e9a29e0f570e81971defe9bc76309c2fb4a5631fff46	2026-08-07 17:39:22.609482+00	20260807173922_init_clean_chat_schema	\N	\N	2026-08-07 17:39:22.54753+00	1
20e76699-e376-4a2f-8a26-517f15305fe9	7a05c46ede73c338bd8e208acf497b790c20606bec2818a515063b9cf5fb8d82	2026-08-09 19:02:27.492513+00	20260809190227_add_reply_to_message	\N	\N	2026-08-09 19:02:27.476948+00	1
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (id, username, email, role, password, avatar, created_at, updated_at) FROM stdin;
5f29f8f4-ebd7-4546-908c-aa165e693b6b	alexbibisdfg	vladisimusas@gmail.com	USER	$2b$08$gRthbq3RtmlGCEcEngmLNOlm9uAsC.Wh00N45UyiI5RcFInQZLZGy	\N	2026-08-07 21:30:33.534	2026-08-07 21:30:33.534
b42fed72-ec3b-4695-8ada-0b7fc53e6a08	alexbibisdfgff	vladisimusadfs@gmail.com	USER	$2b$08$QOegx0JlxzTp8fAmhmL/VePuANki//Oxv2wXWNQ/61DZ/2bt9q5Z2	\N	2026-08-07 21:53:45.072	2026-08-07 21:53:45.072
7ae3772c-090c-44a1-a1fa-84fd5685fae3	alex1	vlads@gmail.com	USER	$2b$08$RPcHAeCrH0UZziXdN2IZXOnqxqEpsQnxvoEVouA88vRen7An.lWyi	\N	2026-08-09 18:36:19.34	2026-08-09 18:36:19.34
0983590f-2fd1-4672-a102-71eb728d72db	alex12	vlad22s@gmail.com	USER	$2b$08$2hgfZLl/7PKIsfc.geWWBeuuJlLWD/hIvnl0cYbNMjnILtUlCuTAC	\N	2026-08-09 18:37:46.737	2026-08-09 18:37:46.737
d1e04ec8-ffa7-4c70-b9fe-1d079be8e54d	alex123	vlad22ss@gmail.com	USER	$2b$08$chBj/evIMHCILTkWM/1ouu14h1w/Wikocv65XKo45grXqyKRU4w6C	\N	2026-08-09 18:40:01.429	2026-08-09 18:40:01.429
07cb0cd6-42ce-486d-b3eb-194f04cf818f	alex1233	vlad22sss@gmail.com	USER	$2b$08$SQrDMEuwG00T9sRif4ZKx.XFWNrIsCDLdA.mGiKeb4WDuaqBeN03W	\N	2026-08-09 18:44:29.138	2026-08-09 18:44:29.138
800d532a-0fb6-413f-b542-0b591f414ff4	alex12334	vlad22ssss@gmail.com	USER	$2b$08$TGMw1ze3vMuM7XANUyidFu6s2l5amlO9u3t7l40ZFvcLlmqjr5wbe	\N	2026-08-09 18:45:30.143	2026-08-09 18:45:30.143
88d17dd6-002f-4725-a271-b1b5ce20ea26	alXfd	vlad22sыsss@gmail.com	USER	$2b$08$kfT0iqpg5YsmMknULzWczuNz6YjrrRMkSJ0gEuiuY5m9RT1dHFzQ2	\N	2026-08-09 18:51:03.076	2026-08-09 18:51:03.076
dd11e43d-4e2a-4e9f-aab5-7ae3d9593df0	alXsfd	vlad22sыssss@gmail.com	USER	$2b$08$CbPEOuqbxcc9hRlWKxzM4u4BP87.C6ZHr0gcafVbg3jPKztEl9N7.	\N	2026-08-09 22:04:30.808	2026-08-09 22:04:30.808
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, text, "streamId", "accountId", created_at, "replyToId") FROM stdin;
62f5ae3e-8331-42bc-a59d-014b536a987e	Hello1	stream_test_id_1	7ae3772c-090c-44a1-a1fa-84fd5685fae3	2026-08-09 18:36:56.689	\N
9b2b8f80-6b18-4192-9e7c-7afaa6b1b337	Hello1	stream_test_id_1	7ae3772c-090c-44a1-a1fa-84fd5685fae3	2026-08-09 18:37:32.772	\N
db510bee-a021-46b4-afb5-a39f9140a0f2	Hello2	stream_test_id_1	0983590f-2fd1-4672-a102-71eb728d72db	2026-08-09 18:38:24.784	\N
bdb34c34-a8dd-48f7-b30a-6386943538d3	Hello3	stream_test_id_1	0983590f-2fd1-4672-a102-71eb728d72db	2026-08-09 18:39:46.097	\N
608d7c39-1c52-47f8-9eed-ea7c0246fe32	Hello Vlad!	stream_test_id_1	07cb0cd6-42ce-486d-b3eb-194f04cf818f	2026-08-09 18:45:21.503	\N
68157382-042a-44c3-9692-3099f0bef1a6	Hi Alex1 how are you?	stream_test_id_1	dd11e43d-4e2a-4e9f-aab5-7ae3d9593df0	2026-08-09 22:05:36.984	\N
cf70ba6e-10a1-4347-902e-aa554853c69f	Hi Alex1 how are you fffffffffff?	stream_test_id_1	dd11e43d-4e2a-4e9f-aab5-7ae3d9593df0	2026-08-09 22:06:55.527	62f5ae3e-8331-42bc-a59d-014b536a987e
\.


--
-- Data for Name: streams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.streams (id, title, "accountId", created_at, updated_at) FROM stdin;
stream_test_id_1	My First Test Stream	5f29f8f4-ebd7-4546-908c-aa165e693b6b	2026-08-07 21:32:01.173	2026-08-07 21:32:01.173
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public?schema=prisma_shadow; Owner: postgres
--

COPY "public?schema=prisma_shadow".accounts (id, username, email, role, password, avatar, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public?schema=prisma_shadow; Owner: postgres
--

COPY "public?schema=prisma_shadow".messages (id, text, "streamId", "accountId", created_at) FROM stdin;
\.


--
-- Data for Name: streams; Type: TABLE DATA; Schema: public?schema=prisma_shadow; Owner: postgres
--

COPY "public?schema=prisma_shadow".streams (id, title, "accountId", created_at, updated_at) FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: streams streams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.streams
    ADD CONSTRAINT streams_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public?schema=prisma_shadow; Owner: postgres
--

ALTER TABLE ONLY "public?schema=prisma_shadow".accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public?schema=prisma_shadow; Owner: postgres
--

ALTER TABLE ONLY "public?schema=prisma_shadow".messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: streams streams_pkey; Type: CONSTRAINT; Schema: public?schema=prisma_shadow; Owner: postgres
--

ALTER TABLE ONLY "public?schema=prisma_shadow".streams
    ADD CONSTRAINT streams_pkey PRIMARY KEY (id);


--
-- Name: accounts_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX accounts_email_key ON public.accounts USING btree (email);


--
-- Name: accounts_username_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX accounts_username_key ON public.accounts USING btree (username);


--
-- Name: messages_streamId_accountId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "messages_streamId_accountId_idx" ON public.messages USING btree ("streamId", "accountId");


--
-- Name: streams_accountId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "streams_accountId_key" ON public.streams USING btree ("accountId");


--
-- Name: accounts_email_key; Type: INDEX; Schema: public?schema=prisma_shadow; Owner: postgres
--

CREATE UNIQUE INDEX accounts_email_key ON "public?schema=prisma_shadow".accounts USING btree (email);


--
-- Name: accounts_username_key; Type: INDEX; Schema: public?schema=prisma_shadow; Owner: postgres
--

CREATE UNIQUE INDEX accounts_username_key ON "public?schema=prisma_shadow".accounts USING btree (username);


--
-- Name: messages_streamId_accountId_idx; Type: INDEX; Schema: public?schema=prisma_shadow; Owner: postgres
--

CREATE INDEX "messages_streamId_accountId_idx" ON "public?schema=prisma_shadow".messages USING btree ("streamId", "accountId");


--
-- Name: streams_accountId_key; Type: INDEX; Schema: public?schema=prisma_shadow; Owner: postgres
--

CREATE UNIQUE INDEX "streams_accountId_key" ON "public?schema=prisma_shadow".streams USING btree ("accountId");


--
-- Name: messages messages_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: messages messages_replyToId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_replyToId_fkey" FOREIGN KEY ("replyToId") REFERENCES public.messages(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: messages messages_streamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_streamId_fkey" FOREIGN KEY ("streamId") REFERENCES public.streams(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: streams streams_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.streams
    ADD CONSTRAINT "streams_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: messages messages_accountId_fkey; Type: FK CONSTRAINT; Schema: public?schema=prisma_shadow; Owner: postgres
--

ALTER TABLE ONLY "public?schema=prisma_shadow".messages
    ADD CONSTRAINT "messages_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES "public?schema=prisma_shadow".accounts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: messages messages_streamId_fkey; Type: FK CONSTRAINT; Schema: public?schema=prisma_shadow; Owner: postgres
--

ALTER TABLE ONLY "public?schema=prisma_shadow".messages
    ADD CONSTRAINT "messages_streamId_fkey" FOREIGN KEY ("streamId") REFERENCES "public?schema=prisma_shadow".streams(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: streams streams_accountId_fkey; Type: FK CONSTRAINT; Schema: public?schema=prisma_shadow; Owner: postgres
--

ALTER TABLE ONLY "public?schema=prisma_shadow".streams
    ADD CONSTRAINT "streams_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES "public?schema=prisma_shadow".accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict Ktkv0ibbcHEWHcM6W4nWgArai4v82ubdsAv9LOC3F0AQW76XQeoovnCz0wIOG2Z

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict 9APAhXQBU3AJCQtwVIicoTBm1mMbfjmLHpx1YKmUaTnxbrOoB8raDGOa4sWevz1

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 9APAhXQBU3AJCQtwVIicoTBm1mMbfjmLHpx1YKmUaTnxbrOoB8raDGOa4sWevz1

--
-- Database "websocket_shadow" dump
--

--
-- PostgreSQL database dump
--

\restrict L4jhaRHjSQXrJeZxpQUiYCNwfEbIgnCNXxlRC9EjpjOn1hY0xDeBwoAGuhfcxMC

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: websocket_shadow; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE websocket_shadow WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE websocket_shadow OWNER TO postgres;

\unrestrict L4jhaRHjSQXrJeZxpQUiYCNwfEbIgnCNXxlRC9EjpjOn1hY0xDeBwoAGuhfcxMC
\connect websocket_shadow
\restrict L4jhaRHjSQXrJeZxpQUiYCNwfEbIgnCNXxlRC9EjpjOn1hY0xDeBwoAGuhfcxMC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: Role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Role" AS ENUM (
    'USER',
    'STREAMER',
    'ADMIN'
);


ALTER TYPE public."Role" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    id text NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    role public."Role" DEFAULT 'USER'::public."Role" NOT NULL,
    password text NOT NULL,
    avatar text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id text NOT NULL,
    text text,
    "streamId" text NOT NULL,
    "accountId" text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "replyToId" text
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: streams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.streams (
    id text NOT NULL,
    title text NOT NULL,
    "accountId" text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.streams OWNER TO postgres;

--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (id, username, email, role, password, avatar, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, text, "streamId", "accountId", created_at, "replyToId") FROM stdin;
\.


--
-- Data for Name: streams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.streams (id, title, "accountId", created_at, updated_at) FROM stdin;
\.


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: streams streams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.streams
    ADD CONSTRAINT streams_pkey PRIMARY KEY (id);


--
-- Name: accounts_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX accounts_email_key ON public.accounts USING btree (email);


--
-- Name: accounts_username_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX accounts_username_key ON public.accounts USING btree (username);


--
-- Name: messages_streamId_accountId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "messages_streamId_accountId_idx" ON public.messages USING btree ("streamId", "accountId");


--
-- Name: streams_accountId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "streams_accountId_key" ON public.streams USING btree ("accountId");


--
-- Name: messages messages_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: messages messages_replyToId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_replyToId_fkey" FOREIGN KEY ("replyToId") REFERENCES public.messages(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: messages messages_streamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_streamId_fkey" FOREIGN KEY ("streamId") REFERENCES public.streams(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: streams streams_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.streams
    ADD CONSTRAINT "streams_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict L4jhaRHjSQXrJeZxpQUiYCNwfEbIgnCNXxlRC9EjpjOn1hY0xDeBwoAGuhfcxMC

--
-- PostgreSQL database cluster dump complete
--

