--
-- PostgreSQL database cluster dump
--

\restrict k9cYnBdWbPl1nAMqIK0ev10g68R85v8ZX0p83kqoGaapZoZRTr5ZlxdFzesXG7w

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:i6TylttXEtOGY0HwNAoUfw==$yR+5aSGRO4pozJ+VubT1uwP+DV0UdrdtkJMHpM5l1Cg=:fuOnHyA11LFBv2UMWKcHr6jH9zOlZi5PakOKVUymgLQ=';

--
-- User Configurations
--








\unrestrict k9cYnBdWbPl1nAMqIK0ev10g68R85v8ZX0p83kqoGaapZoZRTr5ZlxdFzesXG7w

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict yS6fvqg3hglC5gKKR4EqL4qHAUQOMs1ZWLK8TGJXg2b0glgRwu1ysOl44kGlUj8

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict yS6fvqg3hglC5gKKR4EqL4qHAUQOMs1ZWLK8TGJXg2b0glgRwu1ysOl44kGlUj8

--
-- Database "auth_service" dump
--

--
-- PostgreSQL database dump
--

\restrict vBQTva2bfFZwfNYSpJB2esZPcHTh99HLVK7JIY5UafT8con1SeiXNYMOCpheQ9q

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth_service; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE auth_service WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE auth_service OWNER TO postgres;

\unrestrict vBQTva2bfFZwfNYSpJB2esZPcHTh99HLVK7JIY5UafT8con1SeiXNYMOCpheQ9q
\connect auth_service
\restrict vBQTva2bfFZwfNYSpJB2esZPcHTh99HLVK7JIY5UafT8con1SeiXNYMOCpheQ9q

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: public?schema=prisma_shadow; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "public?schema=prisma_shadow";


ALTER SCHEMA "public?schema=prisma_shadow" OWNER TO postgres;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Role" AS ENUM (
    'USER',
    'ADMIN'
);


ALTER TYPE public."Role" OWNER TO postgres;

--
-- Name: StreamStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."StreamStatus" AS ENUM (
    'LIVE',
    'OFFLINE',
    'PAUSED'
);


ALTER TYPE public."StreamStatus" OWNER TO postgres;

--
-- Name: Role; Type: TYPE; Schema: public?schema=prisma_shadow; Owner: postgres
--

CREATE TYPE "public?schema=prisma_shadow"."Role" AS ENUM (
    'USER',
    'STREAMER',
    'ADMIN'
);


ALTER TYPE "public?schema=prisma_shadow"."Role" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    id text NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    role public."Role" DEFAULT 'USER'::public."Role" NOT NULL,
    password text NOT NULL,
    avatar text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: followers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.followers (
    id text NOT NULL,
    "folowingId" text NOT NULL,
    "streamerId" text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    is_notified boolean DEFAULT true NOT NULL
);


ALTER TABLE public.followers OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id text NOT NULL,
    text text,
    "streamId" text NOT NULL,
    "accountId" text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "replyToId" text
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    "accountId" text NOT NULL,
    type text NOT NULL,
    message text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "streamId" text NOT NULL
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: stream_ban_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stream_ban_list (
    id text NOT NULL,
    "streamId" text NOT NULL,
    "userId" text NOT NULL,
    "bannedBy" text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.stream_ban_list OWNER TO postgres;

--
-- Name: streams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.streams (
    id text NOT NULL,
    title text NOT NULL,
    "accountId" text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    status public."StreamStatus" DEFAULT 'OFFLINE'::public."StreamStatus" NOT NULL
);


ALTER TABLE public.streams OWNER TO postgres;

--
-- Name: accounts; Type: TABLE; Schema: public?schema=prisma_shadow; Owner: postgres
--

CREATE TABLE "public?schema=prisma_shadow".accounts (
    id text NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    role "public?schema=prisma_shadow"."Role" DEFAULT 'USER'::"public?schema=prisma_shadow"."Role" NOT NULL,
    password text NOT NULL,
    avatar text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public?schema=prisma_shadow".accounts OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: public?schema=prisma_shadow; Owner: postgres
--

CREATE TABLE "public?schema=prisma_shadow".messages (
    id text NOT NULL,
    text text,
    "streamId" text NOT NULL,
    "accountId" text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public?schema=prisma_shadow".messages OWNER TO postgres;

--
-- Name: streams; Type: TABLE; Schema: public?schema=prisma_shadow; Owner: postgres
--

CREATE TABLE "public?schema=prisma_shadow".streams (
    id text NOT NULL,
    title text NOT NULL,
    "accountId" text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE "public?schema=prisma_shadow".streams OWNER TO postgres;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
b010303f-0201-4977-bb39-8093fc29cadf	bd67384cb72fb175c9b2e9a29e0f570e81971defe9bc76309c2fb4a5631fff46	2026-08-07 17:39:22.609482+00	20260807173922_init_clean_chat_schema	\N	\N	2026-08-07 17:39:22.54753+00	1
20e76699-e376-4a2f-8a26-517f15305fe9	7a05c46ede73c338bd8e208acf497b790c20606bec2818a515063b9cf5fb8d82	2026-08-09 19:02:27.492513+00	20260809190227_add_reply_to_message	\N	\N	2026-08-09 19:02:27.476948+00	1
d5bab652-3265-417d-8f81-b84a2b9b3cec	dceea930d0a281eee7034cc1bcdb2fe4230bf0fd1992bd8f53be02350704b39f	2026-08-10 10:55:54.76239+00	20260810105554_add_stream_ban_list	\N	\N	2026-08-10 10:55:54.741533+00	1
506e6fbb-6197-46b1-87f2-a2169f480ecd	f5c5dc4ed14e76519e89f6652e4243ecc01fdaa21e8675f74d7b6ecca82ec5f5	2026-08-10 11:56:01.242907+00	20260810115601_add_index_and_relation_tol_stream_ban_list_stream	\N	\N	2026-08-10 11:56:01.223319+00	1
2c49be5a-228b-4eda-a230-934f48d3ed83	4147383b005bb13dee2b02cfb4ad3227fe93219cc98273432e91ea82452312bb	2026-08-19 20:04:51.385666+00	20260819200451_add_notification_model	\N	\N	2026-08-19 20:04:51.324356+00	1
79456322-0e5c-4c14-8f72-06aeac5deccc	9b7a19978ec966b4c6575daf429c9573171f578418a67e4137c6631b8fddf56f	2026-08-27 14:34:21.138263+00	20260827143421_make_notification_relation_to_stream_id	\N	\N	2026-08-27 14:34:21.104729+00	1
a6107527-4c41-40f5-bc24-5e57ff4dc8a3	4baf281ad9882291352ed351b2d4f1241cb7eecdb777909ebc1cf6eaaed19b57	2026-08-27 16:57:11.143411+00	20260827165413_delete_streamer_role	\N	\N	2026-08-27 16:57:11.107532+00	1
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (id, username, email, role, password, avatar, created_at, updated_at) FROM stdin;
5f29f8f4-ebd7-4546-908c-aa165e693b6b	alexbibisdfg	vladisimusas@gmail.com	USER	$2b$08$gRthbq3RtmlGCEcEngmLNOlm9uAsC.Wh00N45UyiI5RcFInQZLZGy	\N	2026-08-07 21:30:33.534	2026-08-07 21:30:33.534
b42fed72-ec3b-4695-8ada-0b7fc53e6a08	alexbibisdfgff	vladisimusadfs@gmail.com	USER	$2b$08$QOegx0JlxzTp8fAmhmL/VePuANki//Oxv2wXWNQ/61DZ/2bt9q5Z2	\N	2026-08-07 21:53:45.072	2026-08-07 21:53:45.072
7ae3772c-090c-44a1-a1fa-84fd5685fae3	alex1	vlads@gmail.com	USER	$2b$08$RPcHAeCrH0UZziXdN2IZXOnqxqEpsQnxvoEVouA88vRen7An.lWyi	\N	2026-08-09 18:36:19.34	2026-08-09 18:36:19.34
0983590f-2fd1-4672-a102-71eb728d72db	alex12	vlad22s@gmail.com	USER	$2b$08$2hgfZLl/7PKIsfc.geWWBeuuJlLWD/hIvnl0cYbNMjnILtUlCuTAC	\N	2026-08-09 18:37:46.737	2026-08-09 18:37:46.737
d1e04ec8-ffa7-4c70-b9fe-1d079be8e54d	alex123	vlad22ss@gmail.com	USER	$2b$08$chBj/evIMHCILTkWM/1ouu14h1w/Wikocv65XKo45grXqyKRU4w6C	\N	2026-08-09 18:40:01.429	2026-08-09 18:40:01.429
07cb0cd6-42ce-486d-b3eb-194f04cf818f	alex1233	vlad22sss@gmail.com	USER	$2b$08$SQrDMEuwG00T9sRif4ZKx.XFWNrIsCDLdA.mGiKeb4WDuaqBeN03W	\N	2026-08-09 18:44:29.138	2026-08-09 18:44:29.138
800d532a-0fb6-413f-b542-0b591f414ff4	alex12334	vlad22ssss@gmail.com	USER	$2b$08$TGMw1ze3vMuM7XANUyidFu6s2l5amlO9u3t7l40ZFvcLlmqjr5wbe	\N	2026-08-09 18:45:30.143	2026-08-09 18:45:30.143
88d17dd6-002f-4725-a271-b1b5ce20ea26	alXfd	vlad22sыsss@gmail.com	USER	$2b$08$kfT0iqpg5YsmMknULzWczuNz6YjrrRMkSJ0gEuiuY5m9RT1dHFzQ2	\N	2026-08-09 18:51:03.076	2026-08-09 18:51:03.076
dd11e43d-4e2a-4e9f-aab5-7ae3d9593df0	alXsfd	vlad22sыssss@gmail.com	USER	$2b$08$CbPEOuqbxcc9hRlWKxzM4u4BP87.C6ZHr0gcafVbg3jPKztEl9N7.	\N	2026-08-09 22:04:30.808	2026-08-09 22:04:30.808
5cc635e1-0e45-4521-9037-883557eb12a2	halis	kioru@gmail.com	USER	$2b$08$LSS3zkK4IZycgYdLglFbiO/GESY7ju8OHK1Fb2JkjP.JNk83H/oNK	\N	2026-08-10 16:49:28.258	2026-08-10 16:49:28.258
4e641481-5ea4-42da-ac77-79b0c5e9ff4f	haliыs	kioruыы@gmail.com	USER	$2b$08$oKo0fDGlRbJyU6D0AwdiPeIWmR27H5xzqkOcF5ugv8cknGzJjVOO.	\N	2026-08-10 16:49:52.066	2026-08-10 16:49:52.066
023387bf-cf09-41d6-a278-96c5dc205d04	halisыswww	kaorusssss@gmail.com	USER	$2b$08$R1vXUQnRz3olCTPfaLUOpO/61lL2YA/E6Sl8lx18ZoGaSpiFRZm/W	\N	2026-08-10 17:13:23.594	2026-08-10 17:13:23.594
8b2b799d-62c0-48fb-affd-3a45ca9215e0	bigotgff	gilerio@gmail.com	USER	$2b$08$DGZ2Z1y57r0pq45nAVf9heov7X6omSnsT9UKX9fkUd8yUBE6zKFe.	\N	2026-08-12 12:12:07.364	2026-08-12 12:12:07.364
0f9df50d-f36e-4372-aefb-d73308bba035	gendalf	havasag@gmail.com	USER	$2b$08$vZvgzZmI.CJq5Z2U.HyqsuB8SmblaN0Y15wsnPejMaglcZVYwuBoi	\N	2026-08-12 12:23:27.618	2026-08-12 12:23:27.618
a4396ab7-7d47-4022-a36d-c951dd466b2d	gfgrtrtr	vivivivi@gmail.com	USER	$2b$08$QabfM/m02w4BesRJZ1/0E.lTCwaH.dlFaWUP84/HdlUedVClvznmu	\N	2026-08-15 18:31:07.812	2026-08-15 18:31:07.812
d70bb38e-5900-47da-bfea-660cd4e53599	gfgrtrtddr	vivivivddi@gmail.com	USER	$2b$08$hc76yuoROyQoCtUKXuV2juZstpKiwqq8bWESwpUk7k44jA3PZmmt6	\N	2026-08-15 21:36:01.759	2026-08-15 21:36:01.759
08b5f019-269e-45d1-b14d-ec9b403762ed	figurist	abvisetk@gmail.com	USER	$2b$08$4yVkqvpn1sNkqKIfu2FICOGq3xActdTCOiRUDWNZnLWAH5yjrHJti	\N	2026-08-15 21:47:34.093	2026-08-15 21:47:34.093
fd5a083d-bb29-4524-8863-5cfd99de93a4	figuristы	abviseыtk@gmail.com	USER	$2b$08$77/B.64szQW6zsFaGPVEY.TaLhFn3rK/XskMIWMwMJejqbSaYvwDi	\N	2026-08-15 22:06:18.31	2026-08-15 22:06:18.31
c761ef48-5164-480b-8695-391d957936c4	figuristdы	abviseыddtk@gmail.com	USER	$2b$08$txAf2le9kwNzWFT/FztnbOpzD3QuauhSxPdW2ljEuWWWbThEENLfO	\N	2026-08-15 22:16:17.726	2026-08-15 22:16:17.726
24979600-580f-4cdd-89cd-2c9f99b5beb5	mirasjof	vladisser@gmail.com	USER	$2b$08$y7puYrkQhdXoVJb.oHcI9OrrbgDK2CyF8cu1UQS/D7IWqb7lzaVZW	\N	2026-08-16 14:47:53.187	2026-08-16 14:47:53.187
a2e07426-ce85-47dc-87f0-bd9f10dee9e1	mikimaus	githabus@gmail.com	USER	$2b$08$s8uwvnWEDgJK7X6LsdWVH.OM0v0QXwFuQmeRy8zAJ2fVUbZVB/tz6	\N	2026-08-17 15:02:31.984	2026-08-17 15:02:31.984
2b56265e-b0e0-4025-b60e-cd2441120b66	kirasau	mikimaus@gmail.com	USER	$2b$08$/NWzHSVB1spb4BH.SmuFpO5/gFCpcvrUWjTiQNv3JRv7LLFTcq/.G	\N	2026-08-20 15:53:31.913	2026-08-20 15:53:31.913
8560bf23-50d5-4a28-9515-f41cfa3206f4	haliыswww	kaorus@gmail.com	USER	$2b$08$555hnKgP6cF8DmDpsQBe4.BN8JT.6M8CwvaZxwNqxxqJbJRTz.1/2	\N	2026-08-10 16:50:55.322	2026-08-10 16:50:55.322
c17c9456-e125-427d-9493-c88435cf9447	XSFDGFFFFFFF	bibibibibibib@gmail.com	USER	$2b$08$swcCR2fwOMBTxcfPQjWqQuqNWA9VKj8nhVIOqODNJ/QFGw8vgeaFm	\N	2026-08-16 14:57:56.769	2026-08-16 14:57:56.769
\.


--
-- Data for Name: followers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.followers (id, "folowingId", "streamerId", created_at, is_notified) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, text, "streamId", "accountId", created_at, "replyToId") FROM stdin;
62f5ae3e-8331-42bc-a59d-014b536a987e	Hello1	stream_test_id_1	7ae3772c-090c-44a1-a1fa-84fd5685fae3	2026-08-09 18:36:56.689	\N
9b2b8f80-6b18-4192-9e7c-7afaa6b1b337	Hello1	stream_test_id_1	7ae3772c-090c-44a1-a1fa-84fd5685fae3	2026-08-09 18:37:32.772	\N
db510bee-a021-46b4-afb5-a39f9140a0f2	Hello2	stream_test_id_1	0983590f-2fd1-4672-a102-71eb728d72db	2026-08-09 18:38:24.784	\N
bdb34c34-a8dd-48f7-b30a-6386943538d3	Hello3	stream_test_id_1	0983590f-2fd1-4672-a102-71eb728d72db	2026-08-09 18:39:46.097	\N
608d7c39-1c52-47f8-9eed-ea7c0246fe32	Hello Vlad!	stream_test_id_1	07cb0cd6-42ce-486d-b3eb-194f04cf818f	2026-08-09 18:45:21.503	\N
68157382-042a-44c3-9692-3099f0bef1a6	Hi Alex1 how are you?	stream_test_id_1	dd11e43d-4e2a-4e9f-aab5-7ae3d9593df0	2026-08-09 22:05:36.984	\N
cf70ba6e-10a1-4347-902e-aa554853c69f	Hi Alex1 how are you fffffffffff?	stream_test_id_1	dd11e43d-4e2a-4e9f-aab5-7ae3d9593df0	2026-08-09 22:06:55.527	62f5ae3e-8331-42bc-a59d-014b536a987e
5882e8ff-8bc0-4c48-9b4d-9d148cfc4b6c	Hi there!	stream_test_id_1	5cc635e1-0e45-4521-9037-883557eb12a2	2026-08-10 16:53:24.31	\N
80302bf7-8e3f-4e62-ae5b-c5eb41f76c8b	Hi there1!	stream_test_id_1	5cc635e1-0e45-4521-9037-883557eb12a2	2026-08-10 16:57:11.339	\N
1a75c9dd-8ec1-4bcf-af01-7c2eefb84ab0	Hi there2!	stream_test_id_1	5cc635e1-0e45-4521-9037-883557eb12a2	2026-08-10 16:57:51.634	\N
d0cdb288-e4ae-42ee-a884-7deb79078e94	Hi there3eeeeeeeeee!	stream_test_id_1	5cc635e1-0e45-4521-9037-883557eb12a2	2026-08-10 17:03:12.121	\N
a5fba663-84f5-4816-9427-2ba1dddd179c	How are youuuuuuuu!	stream_test_id_1	5cc635e1-0e45-4521-9037-883557eb12a2	2026-08-10 17:05:40.814	\N
47eaa2fb-5d0f-4235-8483-f1e1401f5f87	How 12341343434!	stream_test_id_1	023387bf-cf09-41d6-a278-96c5dc205d04	2026-08-10 17:13:50.898	\N
61a2d4d2-9bd5-4c41-bbc4-cd0e2fff2018	How 123413434343!	stream_test_id_1	023387bf-cf09-41d6-a278-96c5dc205d04	2026-08-10 17:16:48.761	\N
b1f6c5e6-8a4e-4984-9e0b-6baf06fca9bb	How 1234134343435555555555!	stream_test_id_1	023387bf-cf09-41d6-a278-96c5dc205d04	2026-08-10 17:19:17.835	\N
ef5c6f35-a094-4385-9a42-abdf702a3657	How 1234134343435555555555!	stream_test_id_1	023387bf-cf09-41d6-a278-96c5dc205d04	2026-08-10 17:19:52.312	\N
588b60ce-a089-4a10-836f-b5cbc26aab9d	Hi there!	stream_test_id_1	8b2b799d-62c0-48fb-affd-3a45ca9215e0	2026-08-12 12:22:39.853	\N
a654a2d0-6472-4d9a-9c2c-4c65b13f9669	Ну ты и козёл	stream_test_id_1	8b2b799d-62c0-48fb-affd-3a45ca9215e0	2026-08-12 12:23:11.925	\N
9afe3612-54f4-4257-abd0-06ef6de71ff2	а ты нет?	stream_test_id_1	0f9df50d-f36e-4372-aefb-d73308bba035	2026-08-12 12:24:08.211	\N
304b2c73-126e-4450-afa7-39df7b75c340	привет	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 15:03:23.294	\N
208ab5e1-f994-45ea-8fa4-40465a56edb8	как ты	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 15:03:24.787	\N
1b00cfed-0b16-4090-b74b-19c2b089c3de	ЧТо нового	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 15:03:27.586	\N
8c0c66a5-eb07-4e2b-9b5c-c4058a6f07b6	Как ты там	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 15:05:05.862	\N
c3f23fd0-4ed9-4b0c-9922-13f7a0835645	gggg	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 15:08:41.55	\N
5354fe7f-b802-4c47-9ff0-983fd3bcacc9	f	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 15:08:47.041	\N
f8c58b92-3ecc-4f98-9c56-fb3af886c362	ffffff	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 15:08:48.455	\N
5795b557-d508-4ab5-bcc1-c2b82cf05826	ghbdt	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 15:11:41.523	\N
f8653199-c266-4212-adb6-3fe95c49b537	fdfd	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 15:11:50.344	\N
91ba214d-a112-4321-a907-90cc7a90235d	dfd	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 15:11:55.389	\N
184416b3-a9ec-49a9-960d-df3bbc074b58	gfg	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 17:50:59.42	\N
e8982524-6acb-4dd6-907b-85564b0182f5	ку	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 18:52:10.972	\N
db82fc48-8023-4c9c-a8ec-dc4fbfca0d87	приве	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 18:53:18.313	\N
9739de4f-cb1c-48fa-8697-d9fb451fdef0	куку	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 18:55:09.683	\N
5c1d24cb-3269-4935-93e8-5655eddca4a3	аапа	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 18:55:47.171	\N
54548f04-051a-4650-8d0c-272b062927f2	fgffg	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 18:56:46.27	\N
848f9b8e-2700-4f67-8c9e-047cd4d7907b	fgfgf	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 18:58:25.129	\N
8020cf1e-fc67-4f05-a5e9-04c3906ad58d	fgfgf	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 18:58:26.171	\N
c57b395b-74ac-4d4b-890c-7f0821003002	fgfgf	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 18:58:26.921	\N
b2b237c1-9468-45d1-a427-49764d0a6428	fgff	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 18:58:27.769	\N
457b4be1-203d-4e03-9cea-653deffc136a	fgfg	stream_test_id_2	a2e07426-ce85-47dc-87f0-bd9f10dee9e1	2026-08-17 18:58:28.486	\N
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, "accountId", type, message, is_read, created_at, "streamId") FROM stdin;
\.


--
-- Data for Name: stream_ban_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stream_ban_list (id, "streamId", "userId", "bannedBy", created_at, updated_at) FROM stdin;
27758e06-0591-4349-9bc0-b6f51b61375e	stream_test_id_1	5cc635e1-0e45-4521-9037-883557eb12a2	8560bf23-50d5-4a28-9515-f41cfa3206f4	2026-08-10 17:12:01.96	2026-08-10 17:12:01.96
8b301fd6-7dde-4cf7-816a-295e2e5a063a	stream_test_id_1	023387bf-cf09-41d6-a278-96c5dc205d04	8560bf23-50d5-4a28-9515-f41cfa3206f4	2026-08-10 17:18:32.557	2026-08-10 17:20:16.23
\.


--
-- Data for Name: streams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.streams (id, title, "accountId", created_at, updated_at, status) FROM stdin;
stream_test_id_1	My First Test Stream	5f29f8f4-ebd7-4546-908c-aa165e693b6b	2026-08-07 21:32:01.173	2026-08-07 21:32:01.173	OFFLINE
stream_test_id_2	My Second Test Stream	c17c9456-e125-427d-9493-c88435cf9447	2026-08-16 15:01:12.212	2026-08-16 15:01:12.212	OFFLINE
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public?schema=prisma_shadow; Owner: postgres
--

COPY "public?schema=prisma_shadow".accounts (id, username, email, role, password, avatar, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public?schema=prisma_shadow; Owner: postgres
--

COPY "public?schema=prisma_shadow".messages (id, text, "streamId", "accountId", created_at) FROM stdin;
\.


--
-- Data for Name: streams; Type: TABLE DATA; Schema: public?schema=prisma_shadow; Owner: postgres
--

COPY "public?schema=prisma_shadow".streams (id, title, "accountId", created_at, updated_at) FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: followers followers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.followers
    ADD CONSTRAINT followers_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: stream_ban_list stream_ban_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stream_ban_list
    ADD CONSTRAINT stream_ban_list_pkey PRIMARY KEY (id);


--
-- Name: streams streams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.streams
    ADD CONSTRAINT streams_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public?schema=prisma_shadow; Owner: postgres
--

ALTER TABLE ONLY "public?schema=prisma_shadow".accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public?schema=prisma_shadow; Owner: postgres
--

ALTER TABLE ONLY "public?schema=prisma_shadow".messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: streams streams_pkey; Type: CONSTRAINT; Schema: public?schema=prisma_shadow; Owner: postgres
--

ALTER TABLE ONLY "public?schema=prisma_shadow".streams
    ADD CONSTRAINT streams_pkey PRIMARY KEY (id);


--
-- Name: accounts_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX accounts_email_key ON public.accounts USING btree (email);


--
-- Name: accounts_username_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX accounts_username_key ON public.accounts USING btree (username);


--
-- Name: followers_folowingId_streamerId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "followers_folowingId_streamerId_key" ON public.followers USING btree ("folowingId", "streamerId");


--
-- Name: messages_streamId_accountId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "messages_streamId_accountId_idx" ON public.messages USING btree ("streamId", "accountId");


--
-- Name: notifications_accountId_is_read_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "notifications_accountId_is_read_idx" ON public.notifications USING btree ("accountId", is_read);


--
-- Name: notifications_accountId_streamId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "notifications_accountId_streamId_key" ON public.notifications USING btree ("accountId", "streamId");


--
-- Name: stream_ban_list_streamId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "stream_ban_list_streamId_userId_key" ON public.stream_ban_list USING btree ("streamId", "userId");


--
-- Name: streams_accountId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "streams_accountId_key" ON public.streams USING btree ("accountId");


--
-- Name: streams_accountId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "streams_accountId_status_idx" ON public.streams USING btree ("accountId", status);


--
-- Name: accounts_email_key; Type: INDEX; Schema: public?schema=prisma_shadow; Owner: postgres
--

CREATE UNIQUE INDEX accounts_email_key ON "public?schema=prisma_shadow".accounts USING btree (email);


--
-- Name: accounts_username_key; Type: INDEX; Schema: public?schema=prisma_shadow; Owner: postgres
--

CREATE UNIQUE INDEX accounts_username_key ON "public?schema=prisma_shadow".accounts USING btree (username);


--
-- Name: messages_streamId_accountId_idx; Type: INDEX; Schema: public?schema=prisma_shadow; Owner: postgres
--

CREATE INDEX "messages_streamId_accountId_idx" ON "public?schema=prisma_shadow".messages USING btree ("streamId", "accountId");


--
-- Name: streams_accountId_key; Type: INDEX; Schema: public?schema=prisma_shadow; Owner: postgres
--

CREATE UNIQUE INDEX "streams_accountId_key" ON "public?schema=prisma_shadow".streams USING btree ("accountId");


--
-- Name: followers followers_folowingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.followers
    ADD CONSTRAINT "followers_folowingId_fkey" FOREIGN KEY ("folowingId") REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: followers followers_streamerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.followers
    ADD CONSTRAINT "followers_streamerId_fkey" FOREIGN KEY ("streamerId") REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages messages_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: messages messages_replyToId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_replyToId_fkey" FOREIGN KEY ("replyToId") REFERENCES public.messages(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: messages messages_streamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_streamId_fkey" FOREIGN KEY ("streamId") REFERENCES public.streams(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: notifications notifications_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: notifications notifications_streamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_streamId_fkey" FOREIGN KEY ("streamId") REFERENCES public.streams(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stream_ban_list stream_ban_list_streamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stream_ban_list
    ADD CONSTRAINT "stream_ban_list_streamId_fkey" FOREIGN KEY ("streamId") REFERENCES public.streams(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: streams streams_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.streams
    ADD CONSTRAINT "streams_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: messages messages_accountId_fkey; Type: FK CONSTRAINT; Schema: public?schema=prisma_shadow; Owner: postgres
--

ALTER TABLE ONLY "public?schema=prisma_shadow".messages
    ADD CONSTRAINT "messages_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES "public?schema=prisma_shadow".accounts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: messages messages_streamId_fkey; Type: FK CONSTRAINT; Schema: public?schema=prisma_shadow; Owner: postgres
--

ALTER TABLE ONLY "public?schema=prisma_shadow".messages
    ADD CONSTRAINT "messages_streamId_fkey" FOREIGN KEY ("streamId") REFERENCES "public?schema=prisma_shadow".streams(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: streams streams_accountId_fkey; Type: FK CONSTRAINT; Schema: public?schema=prisma_shadow; Owner: postgres
--

ALTER TABLE ONLY "public?schema=prisma_shadow".streams
    ADD CONSTRAINT "streams_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES "public?schema=prisma_shadow".accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict vBQTva2bfFZwfNYSpJB2esZPcHTh99HLVK7JIY5UafT8con1SeiXNYMOCpheQ9q

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict PtvdzndWMyTNTfCAiFqAsGFGJBkUKGSWC5tn9HuKlfZJcIxYlgI9EyNKwGd9EzE

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict PtvdzndWMyTNTfCAiFqAsGFGJBkUKGSWC5tn9HuKlfZJcIxYlgI9EyNKwGd9EzE

--
-- Database "websocket_shadow" dump
--

--
-- PostgreSQL database dump
--

\restrict JMHt01S9MBomsX4z7uIqUuai8g8vCq3fMWVxg2sF0akhG4zR9yMx5hQOBqqz1Gc

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: websocket_shadow; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE websocket_shadow WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE websocket_shadow OWNER TO postgres;

\unrestrict JMHt01S9MBomsX4z7uIqUuai8g8vCq3fMWVxg2sF0akhG4zR9yMx5hQOBqqz1Gc
\connect websocket_shadow
\restrict JMHt01S9MBomsX4z7uIqUuai8g8vCq3fMWVxg2sF0akhG4zR9yMx5hQOBqqz1Gc

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: Role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Role" AS ENUM (
    'USER',
    'ADMIN'
);


ALTER TYPE public."Role" OWNER TO postgres;

--
-- Name: StreamStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."StreamStatus" AS ENUM (
    'LIVE',
    'OFFLINE',
    'PAUSED'
);


ALTER TYPE public."StreamStatus" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    id text NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    role public."Role" DEFAULT 'USER'::public."Role" NOT NULL,
    password text NOT NULL,
    avatar text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: followers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.followers (
    id text NOT NULL,
    "folowingId" text NOT NULL,
    "streamerId" text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    is_notified boolean DEFAULT true NOT NULL
);


ALTER TABLE public.followers OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id text NOT NULL,
    text text,
    "streamId" text NOT NULL,
    "accountId" text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "replyToId" text
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    "accountId" text NOT NULL,
    type text NOT NULL,
    message text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "streamId" text NOT NULL
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: stream_ban_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stream_ban_list (
    id text NOT NULL,
    "streamId" text NOT NULL,
    "userId" text NOT NULL,
    "bannedBy" text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.stream_ban_list OWNER TO postgres;

--
-- Name: streams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.streams (
    id text NOT NULL,
    title text NOT NULL,
    "accountId" text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    status public."StreamStatus" DEFAULT 'OFFLINE'::public."StreamStatus" NOT NULL
);


ALTER TABLE public.streams OWNER TO postgres;

--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (id, username, email, role, password, avatar, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: followers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.followers (id, "folowingId", "streamerId", created_at, is_notified) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, text, "streamId", "accountId", created_at, "replyToId") FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, "accountId", type, message, is_read, created_at, "streamId") FROM stdin;
\.


--
-- Data for Name: stream_ban_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stream_ban_list (id, "streamId", "userId", "bannedBy", created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: streams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.streams (id, title, "accountId", created_at, updated_at, status) FROM stdin;
\.


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: followers followers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.followers
    ADD CONSTRAINT followers_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: stream_ban_list stream_ban_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stream_ban_list
    ADD CONSTRAINT stream_ban_list_pkey PRIMARY KEY (id);


--
-- Name: streams streams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.streams
    ADD CONSTRAINT streams_pkey PRIMARY KEY (id);


--
-- Name: accounts_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX accounts_email_key ON public.accounts USING btree (email);


--
-- Name: accounts_username_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX accounts_username_key ON public.accounts USING btree (username);


--
-- Name: followers_folowingId_streamerId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "followers_folowingId_streamerId_key" ON public.followers USING btree ("folowingId", "streamerId");


--
-- Name: messages_streamId_accountId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "messages_streamId_accountId_idx" ON public.messages USING btree ("streamId", "accountId");


--
-- Name: notifications_accountId_is_read_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "notifications_accountId_is_read_idx" ON public.notifications USING btree ("accountId", is_read);


--
-- Name: notifications_accountId_streamId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "notifications_accountId_streamId_key" ON public.notifications USING btree ("accountId", "streamId");


--
-- Name: stream_ban_list_streamId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "stream_ban_list_streamId_userId_key" ON public.stream_ban_list USING btree ("streamId", "userId");


--
-- Name: streams_accountId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "streams_accountId_key" ON public.streams USING btree ("accountId");


--
-- Name: streams_accountId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "streams_accountId_status_idx" ON public.streams USING btree ("accountId", status);


--
-- Name: followers followers_folowingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.followers
    ADD CONSTRAINT "followers_folowingId_fkey" FOREIGN KEY ("folowingId") REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: followers followers_streamerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.followers
    ADD CONSTRAINT "followers_streamerId_fkey" FOREIGN KEY ("streamerId") REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages messages_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: messages messages_replyToId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_replyToId_fkey" FOREIGN KEY ("replyToId") REFERENCES public.messages(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: messages messages_streamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_streamId_fkey" FOREIGN KEY ("streamId") REFERENCES public.streams(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: notifications notifications_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: notifications notifications_streamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_streamId_fkey" FOREIGN KEY ("streamId") REFERENCES public.streams(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stream_ban_list stream_ban_list_streamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stream_ban_list
    ADD CONSTRAINT "stream_ban_list_streamId_fkey" FOREIGN KEY ("streamId") REFERENCES public.streams(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: streams streams_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.streams
    ADD CONSTRAINT "streams_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict JMHt01S9MBomsX4z7uIqUuai8g8vCq3fMWVxg2sF0akhG4zR9yMx5hQOBqqz1Gc

--
-- PostgreSQL database cluster dump complete
--

