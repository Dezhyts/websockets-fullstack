--
-- PostgreSQL database cluster dump
--

\restrict 3eGL6Ag84iye08Tml4iiViYJXwDLcAzYghRLtOslYbW9UbDldU6G3wIhclZUwXV

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:i6TylttXEtOGY0HwNAoUfw==$yR+5aSGRO4pozJ+VubT1uwP+DV0UdrdtkJMHpM5l1Cg=:fuOnHyA11LFBv2UMWKcHr6jH9zOlZi5PakOKVUymgLQ=';

--
-- User Configurations
--








\unrestrict 3eGL6Ag84iye08Tml4iiViYJXwDLcAzYghRLtOslYbW9UbDldU6G3wIhclZUwXV

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict o9khpuaV9ZeM8mL0k4pIot792NMEAqgLi7Ag3vAVcekMfySVra0lgJztNbAjXX8

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict o9khpuaV9ZeM8mL0k4pIot792NMEAqgLi7Ag3vAVcekMfySVra0lgJztNbAjXX8

--
-- Database "auth_service" dump
--

--
-- PostgreSQL database dump
--

\restrict 5G12pUhdjuPiuenugYIq7SFTw6uWTeOjxnUFLHFmFcCBZTRVFGxQxq748ZotKgJ

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth_service; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE auth_service WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE auth_service OWNER TO postgres;

\unrestrict 5G12pUhdjuPiuenugYIq7SFTw6uWTeOjxnUFLHFmFcCBZTRVFGxQxq748ZotKgJ
\connect auth_service
\restrict 5G12pUhdjuPiuenugYIq7SFTw6uWTeOjxnUFLHFmFcCBZTRVFGxQxq748ZotKgJ

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    id text NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    avatar text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id text NOT NULL,
    "streamId" text NOT NULL,
    "accountId" text
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: streams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.streams (
    id text NOT NULL,
    title text NOT NULL,
    "accountId" text NOT NULL
);


ALTER TABLE public.streams OWNER TO postgres;

--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (id, username, email, password, avatar, created_at, updated_at) FROM stdin;
0d1e2f3a-4b5c-6d7e-8f9a-0b1c2d3e4f5a	kate_wilson	kate@gmail.com	hashedPassword_kate77	\N	2026-07-25 18:49:51.251	2026-07-25 18:49:51.251
7a8b9c0d-1e2f-3a4b-5c6d-7e8f9a0b1c2d	max_speed	max@gmail.com	hashedPassword_max44	\N	2026-07-25 18:49:51.251	2026-07-25 18:49:51.251
8b9c0d1e-2f3a-4b5c-6d7e-8f9a0b1c2d3e	maria_art	maria@gmail.com	hashedPassword_maria55	\N	2026-07-25 18:49:51.251	2026-07-25 18:49:51.251
9c0d1e2f-3a4b-5c6d-7e8f-9a0b1c2d3e4f	pavel_tech	pavel@gmail.com	hashedPassword_pavel66	\N	2026-07-25 18:49:51.251	2026-07-25 18:49:51.251
a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d	user_ivan	ivan@gmail.com	hashedPassword_ivan123	\N	2026-07-25 18:49:51.251	2026-07-25 18:49:51.251
b2c3d4e5-f6a7-8b9c-0d1e-2f3a4b5c6d7e	anna_smith	anna.s@gmail.com	hashedPassword_anna456	\N	2026-07-25 18:49:51.251	2026-07-25 18:49:51.251
c3d4e5f6-a7b8-9c0d-1e2f-3a4b5c6d7e8f	sergey_dev	serg@gmail.com	hashedPassword_serg789	\N	2026-07-25 18:49:51.251	2026-07-25 18:49:51.251
cb1d9d61-452c-4366-b78f-93cc08f0cf59	alexbibi	vladis@gmail.com	hashedPassowrd7	\N	2026-07-25 11:56:06.894	2026-07-25 11:56:06.894
d4e5f6a7-b8c9-0d1e-2f3a-4b5c6d7e8f9a	elena_key	elena@gmail.com	hashedPassword_elena11	\N	2026-07-25 18:49:51.251	2026-07-25 18:49:51.251
e5f6a7b8-c9d0-1e2f-3a4b-5c6d7e8f9a0b	dmitry_pro	dima@gmail.com	hashedPassword_dima22	\N	2026-07-25 18:49:51.251	2026-07-25 18:49:51.251
f6a7b8c9-d0e1-2f3a-4b5c-6d7e8f9a0b1c	olga_stream	olga.s@gmail.com	hashedPassword_olga33	\N	2026-07-25 18:49:51.251	2026-07-25 18:49:51.251
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, "streamId", "accountId") FROM stdin;
\.


--
-- Data for Name: streams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.streams (id, title, "accountId") FROM stdin;
\.


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: streams streams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.streams
    ADD CONSTRAINT streams_pkey PRIMARY KEY (id);


--
-- Name: accounts_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX accounts_email_key ON public.accounts USING btree (email);


--
-- Name: accounts_username_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX accounts_username_key ON public.accounts USING btree (username);


--
-- Name: messages_streamId_accountId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "messages_streamId_accountId_idx" ON public.messages USING btree ("streamId", "accountId");


--
-- Name: streams_accountId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "streams_accountId_key" ON public.streams USING btree ("accountId");


--
-- Name: messages messages_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: messages messages_streamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_streamId_fkey" FOREIGN KEY ("streamId") REFERENCES public.streams(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: streams streams_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.streams
    ADD CONSTRAINT "streams_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict 5G12pUhdjuPiuenugYIq7SFTw6uWTeOjxnUFLHFmFcCBZTRVFGxQxq748ZotKgJ

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict PEJW6tmosC9FNi7Dor3UWIJklCDSfbUV8byc2PQcjuxxulvyX8aYesp04eQhPfP

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict PEJW6tmosC9FNi7Dor3UWIJklCDSfbUV8byc2PQcjuxxulvyX8aYesp04eQhPfP

--
-- PostgreSQL database cluster dump complete
--

